const express = require('express');
const router = express.Router();
const DatosPreinscripcion = require('../models/DatosPreinscripcion');

router.post('/', async (req, res) => {
  try {
    const datosPreinscripcion = await DatosPreinscripcion.create(req.body);
    res.status(201).json(datosPreinscripcion);
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al registrar datos de preinscripción', error });
  }
});

router.get('/', async (req, res) => {
  try {
    const datosPreinscripcion = await DatosPreinscripcion.findAll();
    res.json(datosPreinscripcion);
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al obtener los registros', error });
  }
});

module.exports = router;
