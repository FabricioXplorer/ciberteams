const express = require('express');
const router = express.Router();
const Alumno = require('../models/alumno');

router.post('/', async (req, res) => {
  try {
    const alumno = await Alumno.create(req.body);
    res.status(201).json(alumno);
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al registrar alumno', error });
  }
});

router.get('/', async (req, res) => {
  try {
    const alumnos = await Alumno.findAll();
    res.json(alumnos);
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al obtener los registros', error });
  }
});

module.exports = router;
