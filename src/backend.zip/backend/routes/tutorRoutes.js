const express = require('express');
const router = express.Router();
const Tutor = require('../models/tutor');

router.post('/', async (req, res) => {
  try {
    const tutor = await Tutor.create(req.body);
    res.status(201).json(tutor);
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al registrar tutor', error });
  }
});

router.get('/', async (req, res) => {
  try {
    const tutores = await Tutor.findAll();
    res.json(tutores);
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al obtener los registros', error });
  }
});

module.exports = router;
