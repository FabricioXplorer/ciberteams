function GradoSeccion () {
    return(
        <div>
            <h3>Muestra los grados del kinder</h3>
        </div>
    );
}
export default GradoSeccion;