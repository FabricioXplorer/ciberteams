import React from "react";

const DashboardAlumno = () => {
  return (
    <div>
      <h3>Dashboard Alumnos</h3>
    </div>
  );
}

export default DashboardAlumno;
