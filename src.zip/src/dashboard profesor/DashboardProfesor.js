function DashboardProfesor () {
    return(
        <div>
            <h3>muestra los profesores inscritos</h3>
        </div>
    );
}
export default DashboardProfesor;